let todolist = [];

export function getTodos() {
    return todolist;
}

export function getTodo(index) {
    return todolist[index];
}

export function addTodo(texte) {
    todolist.push({
        texte: texte,
        estFait: false
    });

    return todolist.length - 1;
}

export function cocherTodo(index) {
    todolist[index].estFait = !todolist[index].estFait;
}
