import 'dotenv/config'

import express, { json } from 'express'
import helmet from 'helmet'
import cors from 'cors'
import compression from 'compression'
import { addTodo, cocherTodo, getTodos, getTodo } from './model/todo.js'

// Créer le serveur
const app = express();
console.log('Serveur créé');

// Middleware
app.use(helmet());
app.use(cors());
app.use(compression());
app.use(json());
app.use(express.static('public'));

app.get('/', (request, response) => {
    response.status(200).json({salution: 'Allo'});
});

// Ajouter les routes ici...
app.get('/api/todos', (request, response) => {
    let todos = getTodos();
    response.status(200).json(todos);
});

// app.get('/api/todo/:index', (request, response) => {
//     let todo = getTodo(request.params.index);
//     response.status(200).json(todo);
// });

// app.get('/api/todo', (request, response) => {
//     let todo = getTodo(request.query.index);
//     response.status(200).json(todo);
// });

app.post('/api/todo', (request, response) => {
    let index = addTodo(request.body.texte);
    response.status(201).json({ index: index });
});

app.patch('/api/todo', (request, response) => {
    cocherTodo(request.body.index);
    response.status(200).end();
});

// Démarrer le serveur
app.listen(process.env.PORT);
console.log('Serveur démarré sur: http://localhost:' + process.env.PORT);
