const todoList = document.getElementById('todo-list');
const formAdd = document.getElementById('form-add');
const textAdd = document.getElementById('text-add');

function addTodoClient(index, texte, estFait) {
    let li = document.createElement('li');

    let checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = estFait;
    checkbox.addEventListener('change', checkTodoServer);
    checkbox.dataset.index = index;

    let div = document.createElement('div');
    div.innerText = texte;

    li.appendChild(checkbox);
    li.appendChild(div);
    todoList.appendChild(li);
}

async function addTodoServer(event) {
    event.preventDefault();

    let data = {
        texte: textAdd.value
    };

    let response = await fetch('/api/todo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    if(response.ok) {
        let value = await response.json();

        addTodoClient(value.index, data.texte, false);

        textAdd.value = '';
        textAdd.focus();
    }
}

async function checkTodoServer(event) {
    let data = {
        index: event.currentTarget.dataset.index
    }

    let response = await fetch('/api/todo', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    if(response.ok) {
        
    }
}

async function getTodosServer() {
    let response = await fetch('/api/todos');

    if(response.ok) {
        let todos = await response.json();
        
        for(let i = 0 ; i < todos.length ; i++) {
            addTodoClient(i, todos[i].texte, todos[i].estFait);
        }
    }
}

formAdd.addEventListener('submit', addTodoServer);
getTodosServer();
