
var navLinks = document.getElementById("navLinks");
 
//navLinks for toggle menu
function showMenu(){
    navLinks.style.right = "0";
}
 
function hideMenu(){
    navLinks.style.right = "-200px";
}
document.getElementById('showDetails').addEventListener('click', function() {
    var checkboxContainer = document.getElementById('checkboxContainer');
    if (checkboxContainer.style.display === 'none') {
        checkboxContainer.style.display = 'block';
    } else {
        checkboxContainer.style.display = 'none';
    }
});

document.getElementById('showDetailsCouscous').addEventListener('click', function() {
    var checkboxContainerM = document.getElementById('checkboxContainerM');
    if (checkboxContainerM.style.display === 'none') {
        checkboxContainerM.style.display = 'block';
    } else {
        checkboxContainerM.style.display = 'none';
    }
});
document.getElementById('showDetailsCamerounais').addEventListener('click', function() {
    var checkboxContainerCamerounais = document.getElementById('checkboxContainerCamerounais');
    if (checkboxContainerCamerounais.style.display === 'none') {
        checkboxContainerCamerounais.style.display = 'block';
    } else {
        checkboxContainerCamerounais.style.display = 'none';
    }
});
document.getElementById('showDetailsC').addEventListener('click', function() {
    var checkboxC = document.getElementById('checkboxC');
    if (checkboxC.style.display === 'none') {
        checkboxC.style.display = 'block';
    } else {
        checkboxC.style.display = 'none';
    }
});
 